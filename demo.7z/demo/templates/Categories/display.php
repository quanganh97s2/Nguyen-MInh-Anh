 <div class="related">
                <h4><?= __('Related Categories') ?></h4>
                <?php if (!empty($category->child_categories)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Description') ?></th>
                            <th><?= __('Parent Id') ?></th>
                            <th><?= __('Created') ?></th>
                            <th><?= __('Status') ?></th>
                            <th><?= __('Slug') ?></th>
                            <th><?= __('Sort') ?></th>
                            <th><?= __('Modified') ?></th>
                            <th><?= __('User Created') ?></th>
                            <th><?= __('User Modified') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($category->child_categories as $childCategories) : ?>
                        <tr>
                            <td><?= h($childCategories->id) ?></td>
                            <td><?= h($childCategories->name) ?></td>
                            <td><?= h($childCategories->description) ?></td>
                            <td><?= h($childCategories->parent_id) ?></td>
                            <td><?= h($childCategories->created) ?></td>
                            <td><?= h($childCategories->status) ?></td>
                            <td><?= h($childCategories->slug) ?></td>
                            <td><?= h($childCategories->sort) ?></td>
                            <td><?= h($childCategories->modified) ?></td>
                            <td><?= h($childCategories->user_created) ?></td>
                            <td><?= h($childCategories->user_modified) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Categories', 'action' => 'view', $childCategories->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Categories', 'action' => 'edit', $childCategories->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Categories', 'action' => 'delete', $childCategories->id], ['confirm' => __('Are you sure you want to delete # {0}?', $childCategories->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>